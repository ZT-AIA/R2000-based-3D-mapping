# STM32 F4 PTPD

IEEE 1588 PTP daemon for STM32 F4 Discovery board
